async function loadQuiz(){
  const res = await fetch("http://localhost:5000/api/quiz/questions");
  const qs = await res.json();
  let html="";
  qs.forEach(q=>{
    html+=`<p>${q.question}</p>`;
  });
  document.getElementById("app").innerHTML = html;
}
