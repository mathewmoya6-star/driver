const mongoose = require("mongoose");
const Question = require("../models/Question");
const data = require("./questions.json");

mongoose.connect("mongodb://127.0.0.1:27017/meidrive").then(async ()=>{
  await Question.deleteMany();
  await Question.insertMany(data);
  console.log("Seeded 1000 questions");
  process.exit();
});
