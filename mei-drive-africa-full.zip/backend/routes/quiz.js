const router = require("express").Router();
const Question = require("../models/Question");

router.get("/questions", async (req,res)=>{
  const qs = await Question.find().limit(50);
  res.json(qs);
});

module.exports = router;
