const mongoose = require("mongoose");
module.exports = mongoose.model("Score", new mongoose.Schema({
  userId: String,
  score: Number,
  date: Date
}));
