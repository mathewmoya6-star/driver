const mongoose = require("mongoose");
module.exports = mongoose.model("Question", new mongoose.Schema({
  category: String,
  question: String,
  options: [String],
  answer: Number
}));
